nohup java -jar proxy.jar -T client-socks5-ui
